package com.pivotal.hadoop.summary;

import java.util.Arrays;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mrunit.mapreduce.MapDriver;
import org.apache.hadoop.mrunit.mapreduce.MapReduceDriver;
import org.apache.hadoop.mrunit.mapreduce.ReduceDriver;
import org.junit.Before;
import org.junit.Test;

public class AverageConsumptionTest {

	private MapDriver<LongWritable, Text, IntWritable, DoubleWritable> mapDriver;
	private ReduceDriver<IntWritable, DoubleWritable, IntWritable, DoubleWritable> reduceDriver;

	private MapReduceDriver<LongWritable, Text, IntWritable, DoubleWritable, IntWritable, DoubleWritable> mapReduceDriver;

	@Before
	public void setUp() throws Exception {

		AverageConsumptionMapper mapper = new AverageConsumptionMapper();
		AverageConsumptionReducer reducer = new AverageConsumptionReducer();

		mapDriver = MapDriver.newMapDriver(mapper);
		reduceDriver = ReduceDriver.newReduceDriver(reducer);
		mapReduceDriver = MapReduceDriver.newMapReduceDriver(mapper, reducer);
	}

	@Test
	public void testMeanMapper() throws Exception {

		final LongWritable inputKey = new LongWritable(0);
		final Text inputValue = new Text(
				"16/12/2006;17:24:00;4.216;0.418;234.840;18.400;0.000;1.000;17.000");
		final IntWritable outputKey = new IntWritable(2006);
		final DoubleWritable outputValue = new DoubleWritable(18.0);

		mapDriver.withInput(inputKey, inputValue)
				.withOutput(outputKey, outputValue).runTest();

	}

	@Test
	public void testMeanReducer() throws Exception {

		new ReduceDriver<IntWritable, DoubleWritable, IntWritable, DoubleWritable>()
				.withReducer(new AverageConsumptionReducer())
				.withInputKey(new IntWritable(2006))
				.withInputValues(
						Arrays.asList(new DoubleWritable(3.00),
								new DoubleWritable(3.00), new DoubleWritable(
										3.00)))
				.withOutput(new IntWritable(2006), new DoubleWritable(3.00))
				.runTest();
	}

	@Test
	public void testMeanMapReduce() throws Exception {

		mapReduceDriver
				.withInput(
						new LongWritable(0),
						new Text(
								"16/12/2006;17:24:00;4.216;0.418;3.0;18.400;0.000;1.000;17.000"))
				.withInput(
						new LongWritable(1),
						new Text(
								"16/12/2006;17:24:00;4.216;0.418;3.0;18.400;0.000;1.000;17.000"))
				.withInput(
						new LongWritable(2),
						new Text(
								"16/12/2006;17:24:00;4.216;0.418;3;18.400;0.000;1.000;17.000"))
				.withOutput(new IntWritable(2006), new DoubleWritable(18.00))

				.runTest();

	}
}