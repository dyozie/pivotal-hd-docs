package com.pivotal.hadoop.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.hadoop.io.Text;

/**
 * Parses a raw record (line of string data) from data dump into a Java object.
 * 
 * Date;Time;Global_active_power;Global_reactive_power;Voltage;Global_intensity;
 * Sub_metering_1;Sub_metering_2;Sub_metering_3
 * 16/12/2006;17:24:00;4.216;0.418;234.840;18.400;0.000;1.000;17.000
 * 16/12/2006;17:25:00;5.360;0.436;233.630;23.000;0.000;1.000;16.000
 * 16/12/2006;17:26:00;5.374;0.498;233.290;23.000;0.000;2.000;17.000
 * 16/12/2006;17:27:00;5.388;0.502;233.740;23.000;0.000;1.000;17.000
 * 
 */
public class PowerConsumptionRecord {

	Date date;
	Date time;
	double global_Active_Power;
	String season;

	double global_Reactive_Power;
	double voltage;
	double global_Intensity;

	double Sub_Metering_1;
	double Sub_Metering_2;
	double Sub_Metering_3;
	String[] fields;
	int year;
	int month;
	final Calendar cal;
	String inputRecord;

	public PowerConsumptionRecord(String inputString)
			throws IllegalArgumentException {
	
		inputRecord = inputString;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat sdt = new SimpleDateFormat("hh:mm:ss");

		cal = Calendar.getInstance();

		fields = inputString.split(";");

		try {
			/*
			 * Date; Time; Global_active_power; Global_reactive_power; Voltage;
			 * Global_intensity; Sub_metering_1; Sub_metering_2; Sub_metering_3
			 */
			cal.setTime(sdf.parse(fields[0]));
			setYear(fields[0]);
			setDate(sdf.parse(fields[0]));
			setTime(sdt.parse(fields[1]));
			setGlobal_Active_Power((Double.parseDouble(fields[2])));
			setGlobal_Reactive_Power(Double.parseDouble(fields[3]));
			setVoltage(Double.parseDouble(fields[4]));
			setGlobal_Intensity(Double.parseDouble(fields[5]));
			setSub_metering_1((Double.parseDouble(fields[6])));
			setSub_metering_2(Double.parseDouble(fields[7]));
			setSub_metering_3(Double.parseDouble(fields[8]));

		} catch (ParseException exception) {
			throw new IllegalArgumentException(
					"Input string contains an unknown value that could not be parsed",
					exception);
		} catch (NumberFormatException exception) {
			throw new IllegalArgumentException(
					"Input string contains an unknown number value that coud not be parsed",
					exception);
		}
	}

	public void setYear(String date) {
		year = cal.get(Calendar.YEAR);
	}

	public PowerConsumptionRecord(Text inputText)
			throws IllegalArgumentException {
		this(inputText.toString());
	}

	

	public void setMonth() {
		month = cal.get(Calendar.MONTH);
	}

	public int getMonth() {
		return month;
	}

	public int getYear() {
		return year;
	}

	public int getHours() {
		return cal.get(Calendar.HOUR);
	}

	public String getSeason() {
		return season;
	}

	public void setSeason() {
		int month = getMonth();
		switch (month) {
		case 12:
		case 1:
		case 2:
			season = "Winter";
			break;
		case 3:
		case 4:
		case 5:
			season = "Spring";
			break;
		case 6:
		case 7:
		case 8:
			season = "Summer";
			break;
		case 9:
		case 10:
		case 11:
			season = "Autumn";
			break;
		}
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	public double getGlobal_Active_Power() {
		return global_Active_Power;
	}

	public void setGlobal_Active_Power(double global_Active_Power) {
		this.global_Active_Power = global_Active_Power;
	}

	public double getGlobal_Reactive_Power() {
		return global_Reactive_Power;
	}

	public void setGlobal_Reactive_Power(double global_Reactive_Power) {
		this.global_Reactive_Power = global_Reactive_Power;
	}

	public double getVoltage() {
		return voltage;
	}

	public void setVoltage(double voltage) {
		this.voltage = voltage;
	}

	public double getGlobal_Intensity() {
		return global_Intensity;
	}

	public void setGlobal_Intensity(double global_Intensity) {
		this.global_Intensity = global_Intensity;
	}

	public double getSub_metering_1() {
		return Sub_Metering_1;
	}

	public void setSub_metering_1(double sub_metering_1) {
		Sub_Metering_1 = sub_metering_1;
	}

	public double getSub_metering_2() {
		return Sub_Metering_2;
	}

	public void setSub_metering_2(double sub_metering_2) {
		Sub_Metering_2 = sub_metering_2;
	}

	public double getSub_metering_3() {
		return Sub_Metering_3;
	}

	public void setSub_metering_3(double sub_metering_3) {
		Sub_Metering_3 = sub_metering_3;
	}

}
