package com.pivotal.hadoop.summary;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import com.pivotal.hadoop.utils.PowerConsumptionRecord;

public class AverageConsumptionMapper extends
		Mapper<LongWritable, Text, IntWritable, DoubleWritable> {

	IntWritable year = new IntWritable();
	DoubleWritable consumption = new DoubleWritable();
	
	@Override
	protected void map(LongWritable key, Text value, Context context)
			throws IOException, InterruptedException {
		// check if record is valid
		if (!isValidRecord(value.toString())) {
		  return;
		}

		//Prepare the PowerConsumption Record using the value
		PowerConsumptionRecord record = new PowerConsumptionRecord(
		    value.toString());

		double sumOfMeters = record.getSub_metering_1()
		    + record.getSub_metering_2() + record.getSub_metering_3();
		year.set(record.getYear());
		consumption.set(sumOfMeters);
		context.write(year, consumption);
		
		
	}
	
	public boolean isValidRecord(String rawRecord) {
		String[] tokens = rawRecord.split(";");
		return (tokens.length == 9) && !(rawRecord.contains("?"));
	}
	
}
